/* 사이드 패널 화면. 목록을 받아 background 로 넘기고, 진행 상황을 보여준다. */

const $ = (id) => document.getElementById(id);

/* ── 주소 목록 읽기 ──────────────────────────────────────────────
 *
 * 예전 방식은 정규식 하나로 "이름 주소" 를 한 번에 맞추려 했다.
 * 쿠팡 주소는 ?searchId=...&clickEventId=...&q=%EB%9D%BC... 처럼 아주 길어서
 * 붙여넣을 때 줄이 접히거나 뒤가 잘리는 일이 생긴다. 그러면 잘린 주소가
 * 조용히 목록에 들어가 엉뚱한 페이지를 긁고도 "성공" 으로 끝난다.
 *
 * 그래서 방식을 바꿨다.
 *   1) 줄에서 http 가 처음 나오는 자리를 찾는다. 그 앞은 이름, 뒤는 주소다.
 *      → 이름과 주소를 나누는 구분자로 | , 쉼표 , 탭 , 공백 아무거나 쓸 수 있다.
 *   2) 주소에서 딜번호(.../vp/products/숫자)를 뽑아 본다.
 *      못 뽑으면 잘린 주소다. 버리지 않고 화면에 경고로 보여준다.
 *   3) 이름을 안 붙였으면 딜번호를 이름으로 쓴다. 001, 002 보다 안전하다.
 *      줄 순서가 바뀌어도 같은 상품은 늘 같은 이름·같은 폴더로 간다.
 */

const PID_RE = /\/v[pm]\/products\/(\d+)/;

function pidOf(url) {
  try {
    const m = new URL(url).pathname.match(PID_RE);
    return m ? m[1] : "";
  } catch (e) {
    const m = String(url).match(PID_RE);   // new URL 이 실패해도 한 번 더 본다
    return m ? m[1] : "";
  }
}

function cleanUrl(url) {
  // 검색 추적용 꼬리표를 떼어낸다. 상품을 가리키는 데 필요한 건 옵션 번호뿐이다.
  try {
    const u = new URL(url);
    const sp = new URLSearchParams();
    for (const k of ["itemId", "vendorItemId"]) {
      const v = u.searchParams.get(k);
      if (v) sp.set(k, v);
    }
    const q = sp.toString();
    u.search = q ? "?" + q : "";
    u.hash = "";
    return u.href;
  } catch (e) { return url; }
}

function parseItems(text) {
  const items = [];
  const problems = [];
  const seen = new Set();
  let auto = 0;

  const lines = String(text || "").split(/\r?\n/);
  lines.forEach((raw, i) => {
    const line = raw.trim();
    if (!line) return;
    const no = i + 1;

    const at = line.search(/https?:\/\//);
    if (at < 0) {
      problems.push({ no, text: line, why: "주소(http…)가 없는 줄이라 건너뜁니다" });
      return;
    }

    // 이름: 주소 앞부분에서 구분자(| , 탭 공백)를 떼어낸다
    let label = line.slice(0, at).replace(/[|,\t\s]+$/, "").trim();
    // 주소: http 부터 공백이나 | 가 나올 때까지
    let url = line.slice(at).split(/[\s|]/)[0];

    if (!/coupang\.com/.test(url)) {
      problems.push({ no, text: url.slice(0, 50), why: "쿠팡 주소가 아닙니다" });
      return;
    }

    const pid = pidOf(url);
    if (!pid) {
      problems.push({
        no, text: url.slice(0, 50) + (url.length > 50 ? "…" : ""),
        why: "딜번호를 찾을 수 없습니다 — 주소가 잘린 것 같습니다",
      });
      return;
    }

    url = cleanUrl(url);
    if (!label) { label = pid; }                       // 이름이 없으면 딜번호를 쓴다
    let id = label;
    if (seen.has(id)) {
      // 같은 딜번호가 두 번 들어오면 뒤의 것은 버린다. 같은 상품이니 한 번만 하면 된다.
      if (id === pid) { problems.push({ no, text: pid, why: "같은 딜번호가 이미 있어 건너뜁니다" }); return; }
      auto++; id = `${label}_${auto}`;                 // 이름만 겹치면 번호를 붙인다
    }
    seen.add(id);
    items.push({ id, label, url, pid });
  });

  return { items, problems };
}

function esc(s) {
  return String(s == null ? "" : s).replace(/[&<>]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;" }[c]));
}

function preview() {
  const { items, problems } = parseItems($("urls").value);
  const mode = $("folderMode").value;
  if (!items.length && !problems.length) { $("preview").innerHTML = ""; return { items, problems }; }

  const rows = items.map((it) => {
    const folder =
      mode === "label" ? it.label :
      mode === "id_title" ? `${it.pid}_제품명` :
      it.pid;
    return `<tr><td>${esc(it.id)}</td><td class="pid">${esc(it.pid)}</td><td>${esc(folder)}/</td></tr>`;
  }).join("");

  const probs = problems.map((p) =>
    `<div class="bad">${p.no}번째 줄 — ${esc(p.why)}<br><span class="mono">${esc(p.text)}</span></div>`
  ).join("");

  $("preview").innerHTML =
    (items.length
      ? `<div class="okline">확인된 상품 ${items.length}개</div>
         <table><tr><th>항목</th><th>딜번호</th><th>저장될 폴더</th></tr>${rows}</table>`
      : `<div class="bad">확인된 상품이 없습니다.</div>`) + probs;

  return { items, problems };
}

function send(msg) {
  return new Promise((resolve) => chrome.runtime.sendMessage(msg, resolve));
}

/* ── ① 주소 찾기 ────────────────────────────────────────────────
 * 검색목록.json 을 붙여넣으면 제품명으로 쿠팡을 검색해 주소를 찾는다.
 * 여기서는 목록을 읽어 넘기기만 하고, 맞는지 따지는 일은 background 가 한다.
 */
function parseJobs(text) {
  const t = String(text || "").trim();
  if (!t) return { items: [], error: "" };
  let data;
  try { data = JSON.parse(t); }
  catch (e) { return { items: [], error: "이 파일은 검색목록.json 이 아닌 것 같습니다. 받으신 파일을 그대로 골라 주세요." }; }
  if (!Array.isArray(data)) return { items: [], error: "목록(대괄호 [ ] 로 시작하는 형태)이어야 합니다." };
  const items = data.filter((x) => x && x.id && (x.query || x.name));
  if (items.length === 0) return { items: [], error: "읽을 항목이 없습니다. 검색목록.json 이 맞는지 확인해 주세요." };
  return { items, error: "" };
}

let DONE_IDS = new Set();   // 이미 '확실'로 찾은 항목
let VAGUE_IDS = new Set();  // '애매' — 찾긴 했는데 확정하지 않은 항목

function jobsInfo() {
  const { items, error } = parseJobs($("jobs").value);
  if (error) { $("jobsInfo").innerHTML = `<span class="warn">${error}</span>`; $("todo").innerHTML = ""; return items; }
  if (!items.length) { $("jobsInfo").textContent = ""; $("todo").innerHTML = ""; return items; }
  const withPrice = items.filter((x) => x.price).length;
  $("jobsInfo").textContent =
    `${items.length}개 읽음 · 가격이 있어 대조 가능한 것 ${withPrice}개`;
  renderTodo(items);
  return items;
}

/* 무엇을 검색해야 하는지 그대로 보여 준다.
 *
 * 이게 왜 필요한가: 전에는 "제품이 보이는 화면을 여세요"라고만 했다.
 * 사용자는 JSON 덩어리를 붙여넣은 상태라 무엇을 쳐야 하는지 알 길이 없었다.
 * ("화면에 뭘 검색하라는건지 모르겠음")
 * 할 일을 아는 쪽이 할 일을 말해 줘야 한다. 목록에 그 답이 이미 들어 있다.
 */
function renderTodo(items) {
  const g = {};
  for (const it of items) {
    const term = it.listName || it.cat || "-";
    (g[term] = g[term] || { left: [], done: 0, vague: 0 });
    if (DONE_IDS.has(it.id)) g[term].done++;
    else {
      if (VAGUE_IDS.has(it.id)) g[term].vague++;
      g[term].left.push((VAGUE_IDS.has(it.id) ? "△ " : "") + (it.name || it.id));
    }
  }
  // 순서를 고정한다. 목록에 나온 차례 그대로다(= 엑셀 카테고리 순서).
  //
  // 예전에는 '남은 개수가 많은 순'으로 세웠다. 그런데 찾을 때마다 개수가 변하니
  // 줄이 계속 자리를 바꿨다. 방금 보던 줄이 다음에 다른 자리에 있으면
  // 눈으로 따라가기가 어렵다. 진행 상황은 숫자로 읽으면 되고, 자리는 고정이어야 한다.
  // (자바스크립트 객체는 문자열 키의 넣은 순서를 지키므로 정렬하지 않으면 그대로다)
  const terms = Object.entries(g);
  const rows = terms.map(([term, v], i) => {
    if (v.left.length === 0) {
      return `<tr><td class="done">✔</td><td class="term">${esc(term)}</td>
        <td class="done" colspan="2">${v.done}개 다 찾음</td></tr>`;
    }
    return `<tr>
      <td>${i + 1}</td>
      <td class="term">${esc(term)}</td>
      <td>남은 ${v.left.length}개${v.done ? ` (찾음 ${v.done})` : ""}${
        v.vague ? `<br><span style="color:#b8860b">△ 애매 ${v.vague}</span>` : ""}</td>
      <td><button class="copyTerm" data-term="${esc(term)}">복사</button>
          <button class="showNames" data-term="${esc(term)}">제품보기</button></td>
    </tr><tr class="namesRow" data-term="${esc(term)}" style="display:none">
      <td colspan="4"><div class="names">${v.left.map(esc).join("<br>")}</div></td>
    </tr>`;
  }).join("");

  const leftTotal = items.filter((x) => !DONE_IDS.has(x.id)).length;
  const vagueTotal = items.filter((x) => !DONE_IDS.has(x.id) && VAGUE_IDS.has(x.id)).length;
  $("todo").innerHTML =
    `<div style="margin:4px 0 2px"><b>아직 못 찾은 것 ${leftTotal}개</b>` +
    (vagueTotal ? ` <span style="color:#b8860b">(그 중 △ 애매 ${vagueTotal}개 — 후보는
       찾았으나 용량·구성이 어긋나 확정하지 않음. '결과 내보내기'에서 볼 수 있습니다)</span>` : "") +
    `</div>
     <table><tr><th></th><th>검색창에 칠 말</th><th>상태</th><th></th></tr>${rows}</table>`;

  for (const b of document.querySelectorAll(".copyTerm")) {
    b.addEventListener("click", async () => {
      try { await navigator.clipboard.writeText(b.dataset.term); b.textContent = "복사됨"; }
      catch (e) { b.textContent = "복사실패"; }
      setTimeout(() => { b.textContent = "복사"; }, 1500);
    });
  }
  for (const b of document.querySelectorAll(".showNames")) {
    b.addEventListener("click", () => {
      const row = document.querySelector(`.namesRow[data-term="${b.dataset.term}"]`);
      if (!row) return;
      const on = row.style.display === "none";
      row.style.display = on ? "" : "none";
      b.textContent = on ? "접기" : "제품보기";
    });
  }
}

function showPane(id) {
  for (const b of document.querySelectorAll(".tabs button")) {
    b.classList.toggle("on", b.dataset.pane === id);
  }
  for (const d of document.querySelectorAll(".pane")) {
    d.classList.toggle("on", d.id === id);
  }
  send({ cmd: "setMode", mode: id === "paneSearch" ? "search" : "collect" }).then(refresh);
}
for (const b of document.querySelectorAll(".tabs button")) {
  b.addEventListener("click", () => showPane(b.dataset.pane));
}
$("jobs").addEventListener("input", jobsInfo);

/* 파일을 그대로 고르게 한다.
 *
 * 전에는 "검색목록.json 내용을 복사해서 붙여넣으세요"였다. 그래서
 * "파일을 어디에 붙여넣으라는 거냐"는 질문이 나왔다. 당연한 질문이다 —
 * 파일을 받았는데 메모장으로 열어 전체 선택해 복사하라는 건 번거롭고,
 * 폴더에 넣는 것으로 오해하기도 쉽다.
 * 파일을 받았으면 파일로 고르게 하는 게 맞다. 붙여넣기는 남겨 두되 뒤로 뺀다.
 */
$("pickFile").addEventListener("click", () => $("jobsFile").click());

/* 확장 안에 목록을 함께 넣어 두고, 패널을 열면 알아서 읽는다.
 *
 * 왜: 목록 파일을 따로 보내 놓고 "그 파일을 고르세요"라고 했더니
 * "이 파일이 폴더에는 없는데?" 가 됐다. 당연하다 — 확장 폴더에 있는 파일이
 * 아니라 채팅으로 받은 파일이었으니까.
 * 찾아야 할 파일이 하나라도 있으면 그게 걸림돌이 된다. 아예 같이 넣는다.
 * (파일 이름은 영문으로 둔다. 한글 파일명이 경로에서 깨진 적이 있다.)
 */
async function loadBundled() {
  try {
    const res = await fetch(chrome.runtime.getURL("search_list.json"));
    if (!res.ok) return false;
    const text = await res.text();
    const { items } = parseJobs(text);
    if (!items.length) return false;
    $("jobs").value = text;
    jobsInfo();
    return items.length;
  } catch (e) { return false; }
}

$("jobsFile").addEventListener("change", async (e) => {
  const f = e.target.files && e.target.files[0];
  if (!f) return;
  try {
    const text = await f.text();
    $("jobs").value = text;
    const items = jobsInfo();
    if (items.length) {
      $("status").textContent =
        `${f.name} 에서 ${items.length}개를 읽었습니다.\n` +
        `아래 표의 '복사' 를 눌러 쿠팡 검색창에 붙여넣으세요.`;
    }
  } catch (err) {
    $("jobsInfo").innerHTML = `<span class="warn">파일을 읽지 못했습니다: ${esc(err.message)}</span>`;
  }
  e.target.value = "";   // 같은 파일을 다시 골라도 동작하도록
});

$("toggleBox").addEventListener("click", () => {
  const w = $("boxWrap");
  const on = w.style.display === "none";
  w.style.display = on ? "" : "none";
  $("toggleBox").textContent = on ? "입력칸 숨기기" : "직접 붙여넣기";
});

$("readList").addEventListener("click", async () => {
  const items = jobsInfo();
  if (!items.length) { $("status").textContent = "먼저 검색목록.json 내용을 붙여넣어 주세요."; return; }
  $("status").textContent = "지금 보는 화면을 읽는 중…";
  const r = await send({ cmd: "readList", items });
  if (!r || !r.ok) {
    $("status").textContent = (r && r.error) || "읽지 못했습니다.";
    if (r && r.log) $("status").textContent += "\n\n" + r.log.join("\n");
    return;
  }
  $("status").textContent =
    `이 화면에서 상품 ${r.total}개를 읽어\n` +
    `확실 ${r.found}개 / 애매 ${r.vague}개를 맞췄습니다.\n` +
    (r.left > 0
      ? `아직 못 찾은 것 ${r.left}개.\n\n다른 화면으로 옮겨서 또 누르시면 됩니다. 결과는 쌓입니다.`
      : `\n다 찾았습니다. '결과 내보내기' 로 저장해 주세요.`);
  refresh();
});

$("openReview").addEventListener("click", async () => {
  await chrome.tabs.create({ url: chrome.runtime.getURL("results.html") });
  $("status").textContent =
    "확인 화면을 새 탭에 열었습니다.\n맞는 후보가 있으면 '이게 맞음'을 눌러 확정해 주세요.";
});

$("startSearch").addEventListener("click", async () => {
  const items = jobsInfo();
  if (!items.length) return;
  const gapMin = Math.max(5, parseInt($("gapMin").value, 10) || 12);
  const gapMax = Math.max(gapMin, parseInt($("gapMax").value, 10) || 25);
  const r = await send({ cmd: "startSearch", items, opts: { gapMin, gapMax } });
  if (!r || !r.ok) { $("status").textContent = r ? r.error : "시작하지 못했습니다."; return; }
  const skipped = r.total - r.queued;
  $("status").textContent = `${r.queued}개를 검색합니다.` +
    (skipped > 0 ? ` (이미 확실하게 찾은 ${skipped}개는 건너뜁니다)` : "") +
    `\n패널을 닫아도 계속 진행됩니다.`;
  refresh();
});

$("stopSearch").addEventListener("click", async () => {
  await send({ cmd: "stop" });
  $("status").textContent = "중단 요청을 보냈습니다. 진행 중인 한 건을 마치고 멈춥니다.";
});

/* 내보낸 검색결과.json 을 되돌린다.
 *
 * 왜 필요한가: 찾은 기록은 chrome.storage.local, 즉 이 크롬 안에만 있다.
 * 확장을 지우면 같이 지워지고, 다른 컴퓨터로도 따라가지 않는다.
 * 실제로 두 번 잃었다(컴퓨터 이동 131건, 재설치 25건).
 * 경고만 띄우고 되돌릴 길을 안 둔 것이 잘못이었다. 저장한 게 있으면
 * 되돌아와야 한다.
 */
$("pickFound").addEventListener("click", () => $("foundFile").click());
$("foundFile").addEventListener("change", async (e) => {
  const f = e.target.files && e.target.files[0];
  e.target.value = "";
  if (!f) return;
  let data;
  try {
    data = JSON.parse(await f.text());
  } catch (err) {
    $("status").textContent = `${f.name} 을 읽지 못했습니다 — JSON 형식이 아닙니다.`;
    return;
  }
  if (!data || typeof data !== "object" || Array.isArray(data)) {
    $("status").textContent =
      `${f.name} 은 주소찾기 결과 파일이 아닌 것 같습니다.\n` +
      `이름이 '1_주소찾기…' 로 시작하는 파일을 고르셨는지 확인해 주세요.`;
    return;
  }
  const r = await send({ cmd: "importFound", found: data });
  if (!r || !r.ok) {
    $("status").textContent = `되돌리지 못했습니다: ${(r && r.error) || "알 수 없는 오류"}`;
    return;
  }
  $("status").textContent =
    `${f.name} 에서 ${r.added}건을 되돌렸습니다.` +
    (r.kept ? ` (이미 찾아 둔 ${r.kept}건은 그대로 뒀습니다)` : "") +
    (r.skipped ? ` (주소가 없는 ${r.skipped}건은 건너뜀)` : "");
  refresh();
});

/* '지금 파일로 저장하기' — 이름 그대로 저장한다.
 *
 * 전에는 결과 페이지를 '열기만' 했다. 거기서 버튼을 한 번 더 눌러야
 * 저장이 됐는데, 버튼 이름은 저장이라고 돼 있었다. 이름이 약속한 일을
 * 안 하는 버튼이었다. 두 번 누르게 할 이유가 없다.
 */
async function saveFoundNow() {
  const r = await send({ cmd: "export" });
  const found = (r && r.found) || {};
  const n = Object.values(found).filter((f) => f && f.verdict === "확실").length;
  if (!Object.keys(found).length) {
    $("status").textContent = "저장할 결과가 없습니다.";
    return;
  }
  // 이름만 보고 무엇인지 알 수 있게 단계번호·카테고리·건수를 넣는다.
  const cats = [...new Set(Object.keys(found).map((s) => s.replace(/-\d+$/, "")))];
  const fname = `1_주소찾기${cats.length === 1 ? "_" + cats[0] : ""}_${Object.keys(found).length}건.json`;
  const blob = new Blob([JSON.stringify(found, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  try {
    await chrome.downloads.download({ url, filename: fname, saveAs: false });
  } catch (e) {
    // 사이드 패널에서 downloads 가 막히는 경우를 대비한 두 번째 길.
    const a = document.createElement("a");
    a.href = url; a.download = fname;
    document.body.appendChild(a); a.click(); a.remove();
  }
  setTimeout(() => URL.revokeObjectURL(url), 60000);
  await send({ cmd: "markExported" });
  $("status").textContent =
    `${fname} 을 다운로드 폴더에 저장했습니다 (확실 ${n}건).\n` +
    `이 파일만 있으면 컴퓨터를 옮기거나 확장을 다시 깔아도 '주소찾기 결과 불러오기' 로 되돌아옵니다.`;
  refresh();
}
$("saveNow").addEventListener("click", saveFoundNow);

$("resetSearch").addEventListener("click", async () => {
  if (!confirm("지금까지 찾은 주소 기록을 지웁니다. 계속할까요?")) return;
  await send({ cmd: "resetSearch" });
  refresh();
});

async function refresh() {
  const s = await send({ cmd: "status" });
  if (!s || !s.ok) { $("status").textContent = "상태를 읽지 못했습니다."; return; }
  const c = s.counts || {};
  const label = { ok: "성공", blocked: "차단", no_images: "이미지없음", fail: "실패" };
  const parts = Object.entries(c).map(([k, v]) => `${label[k] || k} ${v}`);
  const what = s.mode === "search" ? "주소 찾기" : "이미지 수집";
  const lines = [];

  // 남은 시간을 함께 보여 준다. '남은 112개'만으로는 10분인지 한 시간인지 알 수 없다.
  // 설정값이 아니라 **실제로 걸린 속도**로 계산한 값이다.
  let eta = "";
  if (s.secPerItem && s.remaining > 0) {
    const sec = Math.round(s.secPerItem * s.remaining);
    const h = Math.floor(sec / 3600), m = Math.round((sec % 3600) / 60);
    eta = h > 0 ? ` · 남은 시간 약 ${h}시간 ${m}분` : ` · 남은 시간 약 ${Math.max(1, m)}분`;
    const done = new Date(Date.now() + sec * 1000);
    eta += ` (${String(done.getHours()).padStart(2, "0")}:${String(done.getMinutes()).padStart(2, "0")} 쯤 끝남)`;
  }
  lines.push(s.running ? `${what} 진행 중 — 남은 ${s.remaining}개${eta}`
                       : `${what} 대기 중 — 남은 ${s.remaining}개`);
  if (s.running && s.secPerItem && s.doneCount >= 2) {
    lines.push(`한 개당 평균 ${s.secPerItem.toFixed(0)}초 · 지금까지 ${s.doneCount}개 완료`);
  }
  if (s.current) lines.push(`지금: ${s.current}`);
  if (parts.length) lines.push(`결과: ${parts.join(" / ")}`);
  if (s.message) lines.push(s.message);
  if (s.recent && s.recent.length) {
    lines.push("");
    for (const x of s.recent) lines.push(`  ${x}`);
  }
  $("status").textContent = lines.join("\n");
  $("start").disabled = s.running;
  $("stop").disabled = !s.running;
  $("startSearch").disabled = s.running;
  $("stopSearch").disabled = !s.running;
  // 찾은 것이 있는데 아직 파일로 안 뺐으면 눈에 띄게 알린다.
  // 이 결과는 크롬 안에만 있어서 컴퓨터를 옮기면 따라오지 않는다.
  const found = (s.doneIds || []).length;
  const saved = s.exportedCount || 0;
  // 같은 딜번호가 여러 항목에 붙었으면 알린다. 한 페이지가 서로 다른
  // 두 상품일 수는 없으므로, 적어도 하나는 틀린 것이다.
  const dups = s.dupPids || [];
  if (dups.length) {
    $("dupWarn").style.display = "";
    $("dupWarn").innerHTML =
      `<b>⚠ 같은 딜번호가 여러 항목에 붙었습니다 (${dups.length}건).</b><br>` +
      `한 페이지가 서로 다른 상품일 수는 없으니, 적어도 하나는 틀렸습니다.<br>` +
      dups.map((g) => `&nbsp;&nbsp;· <code>${esc(g.pid)}</code> → ${g.ids.map(esc).join(", ")}`).join("<br>") +
      `<br>'애매한 것 확인하기' 에서 해당 항목의 주소를 다시 넣어 주세요.` +
      `<br><span class="hint">같은 상품이 순위에 두 번 오른 경우라면 그대로 두셔도 됩니다.</span>`;
  } else {
    $("dupWarn").style.display = "none";
  }

  if (found > saved) {
    $("saveWarn").style.display = "";
    // 글자만 바꾼다. 버튼은 panel.html 에 붙박이로 있다.
    $("saveWarnText").innerHTML =
      `<b>⚠ 찾은 ${found}건이 아직 파일로 저장되지 않았습니다.</b><br>` +
      `이 결과는 <b>이 크롬 안에만</b> 있습니다. 다른 컴퓨터로 옮겨지지 않고,
       확장을 지우면 사라집니다.` +
      (saved ? `<br>(마지막 저장: ${saved}건)` : "");
  } else {
    $("saveWarn").style.display = "none";
  }

  if (s.doneIds) {
    const d = new Set(s.doneIds), v = new Set(s.vagueIds || []);
    if (d.size !== DONE_IDS.size || v.size !== VAGUE_IDS.size) {
      DONE_IDS = d; VAGUE_IDS = v; jobsInfo();
    }
  }
}

$("useTab").addEventListener("click", async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab || !/coupang\.com/.test(tab.url || "")) {
    $("status").textContent = "지금 탭이 쿠팡 상품 페이지가 아닙니다.";
    return;
  }
  const box = $("urls");
  box.value = (box.value ? box.value.replace(/\s*$/, "") + "\n" : "") + tab.url;
  preview();
});

$("clear").addEventListener("click", () => { $("urls").value = ""; preview(); });

// 주소를 고치면 바로 미리보기를 다시 그린다. 시작 전에 눈으로 확인할 수 있게.
$("urls").addEventListener("input", preview);
$("folderMode").addEventListener("change", preview);

$("start").addEventListener("click", async () => {
  const { items, problems } = preview();
  if (items.length === 0) {
    $("status").textContent = "쿠팡 상품 주소를 한 줄에 하나씩 넣어 주세요.";
    return;
  }
  if (problems.length) {
    const ok = confirm(
      `읽을 수 없는 줄이 ${problems.length}개 있습니다.\n` +
      `이 줄들은 건너뛰고 ${items.length}개만 수집합니다.\n\n그대로 시작할까요?`);
    if (!ok) return;
  }
  const gapMin = Math.max(5, parseInt($("gapMin").value, 10) || 12);
  const gapMax = Math.max(gapMin, parseInt($("gapMax").value, 10) || 25);
  const saveImages = !$("urlOnly").checked;
  const tryMobile = $("tryMobile").checked;
  const folderMode = $("folderMode").value;
  const r = await send({
    cmd: "start",
    items: items.map(({ id, label, url }) => ({ id, label, url })),
    opts: { gapMin, gapMax, saveImages, tryMobile, folderMode },
  });
  if (!r || !r.ok) { $("status").textContent = r ? r.error : "시작하지 못했습니다."; return; }
  $("status").textContent = `${r.queued}개를 시작했습니다. 패널을 닫아도 계속 진행됩니다.` +
    (saveImages ? "" : "\n이미지 파일은 저장하지 않습니다. 이미지 주소는 기록에 남습니다.");
  refresh();
});

$("stop").addEventListener("click", async () => {
  await send({ cmd: "stop" });
  $("status").textContent = "중단 요청을 보냈습니다. 진행 중인 한 건을 마치고 멈춥니다.";
});

$("export").addEventListener("click", async () => {
  // 패널에서 직접 내려받지 않는다. 패널이 닫히면 임시 주소가 사라져서 저장이
  // 조용히 실패한다(실제로 그렇게 실패했다). 닫히지 않는 탭에서 처리한다.
  await chrome.tabs.create({ url: chrome.runtime.getURL("results.html") });
  $("status").textContent = "결과 페이지를 새 탭에 열었습니다.\n거기서 저장하거나 복사하시면 됩니다.";
});

$("reset").addEventListener("click", async () => {
  if (!confirm("지금까지의 수집 기록을 지웁니다. 계속할까요?\n(내려받은 이미지는 지워지지 않습니다)")) return;
  await send({ cmd: "reset" });
  refresh();
});

preview();
refresh();

/* ② 이미지 수집용 주소 목록도 확장에 넣어 둔다.
 *
 * ① 에서 목록 파일을 찾게 만들었다가 "이 파일이 폴더에는 없는데?" 를 겪었다.
 * 같은 실수를 반복하지 않는다. 275개 주소를 손으로 붙여넣게 하면 안 된다.
 */
let COLLECT = [];

async function loadCollect() {
  try {
    const res = await fetch(chrome.runtime.getURL("collect_list.json"));
    if (!res.ok) return;
    COLLECT = await res.json();
    const core = COLLECT.filter((x) => x.core).length;
    const merged = COLLECT.reduce((n, x) => n + ((x.alsoFor || []).length), 0);
    $("collectInfo").innerHTML =
      `확장에 <b>상세페이지 ${COLLECT.length}개</b>가 들어 있습니다 (핵심 ${core} / 확장 ${COLLECT.length - core}).` +
      (merged ? `<br>같은 상품이 두 번 올라온 ${merged}건은 <b>한 번만</b> 수집합니다.` : "");
  } catch (e) {
    $("collectInfo").innerHTML =
      `<span class="warn">주소 목록을 읽지 못했습니다. 아래에 직접 붙여넣어 주세요.</span>`;
  }
}

function fillUrls(list) {
  if (!list.length) { $("status").textContent = "넣을 주소가 없습니다."; return; }
  $("urls").value = list.map((x) => `${x.id} | ${x.url}`).join("\n");
  // 폴더 이름을 '내가 붙인 이름'(= 세탁세제-01)으로 맞춘다.
  // 딜번호로 두면 나중에 엑셀과 맞춰 보려면 번호를 일일이 대조해야 한다.
  // 항목 번호가 곧 엑셀의 행이므로 그대로 쓰는 게 맞다.
  $("folderMode").value = "label";
  const items = preview();
  $("status").textContent =
    `${items.length}개를 넣었습니다.\n` +
    `폴더 이름은 '${items[0] ? items[0].id : "카테고리-순위"}' 처럼 붙습니다 (엑셀 항목 번호와 같음).\n` +
    `예상 ${Math.round(list.length * 18.5 / 60)}분. 켜 두고 다른 일 하셔도 됩니다.\n` +
    `아래 미리보기에서 확인하고 '수집 시작' 을 누르세요.`;
}

$("loadCore").addEventListener("click", () => fillUrls(COLLECT.filter((x) => x.core)));
$("loadAll").addEventListener("click", () => fillUrls(COLLECT));

/* ①에서 찾은 주소를 그대로 ②에 넣는다.
 *
 * 주소는 이미 확장 안(state.found)에 들어 있다. 그걸 꺼내 쓰면 되는데
 * 전에는 그 길이 없어서, 파일로 빼서 → 나한테 보내고 → 내가 목록을 새로
 * 만들어 → 다음 판을 설치하는 왕복이 있었다. 기다릴 이유가 없는 기다림이다.
 *
 * '확실'만 넣는다. 애매는 아직 어느 상품인지 정해지지 않았으므로
 * 엉뚱한 상세페이지를 긁어 오게 된다.
 */
$("loadFound").addEventListener("click", async () => {
  const r = await send({ cmd: "export" });
  const found = (r && r.found) || {};
  const list = Object.entries(found)
    .filter(([, f]) => f && f.verdict === "확실" && f.url)
    .map(([id, f]) => ({ id, url: f.url }))
    .sort((a, b) => a.id.localeCompare(b.id, "ko", { numeric: true }));
  if (!list.length) {
    $("status").textContent =
      "①에서 '확실'로 찾은 주소가 아직 없습니다.\n" +
      "①번 탭에서 먼저 주소를 찾아 주세요.";
    return;
  }
  const vague = Object.values(found).filter((f) => f && f.verdict === "애매").length;
  fillUrls(list);
  if (vague) {
    $("status").textContent +=
      `\n\n△ 애매 ${vague}개는 넣지 않았습니다 — 아직 어느 상품인지 정해지지 않아,` +
      ` 넣으면 엉뚱한 상세페이지를 받게 됩니다. ①번 탭 '애매한 것 확인하기'에서 정하신 뒤 다시 누르세요.`;
  }
});

// 패널을 열면 확장에 들어 있는 목록을 바로 읽는다. 사용자가 할 일이 없다.
(async () => {
  loadCollect();

  // 판 번호와 '지금 들어 있는 목록이 무엇인지'를 먼저 띄운다.
  // 새 판으로 바꿨는지 아닌지를 사장님이 눈으로 확인할 수 있어야 한다.
  const mf = chrome.runtime.getManifest();
  $("verLine").textContent = `버전 ${mf.version}`;

  const n = await loadBundled();
  if (n) {
    const { items } = parseJobs($("jobs").value);
    const cats = [...new Set(items.map((x) => x.listName || x.cat).filter(Boolean))];
    $("verLine").textContent =
      `버전 ${mf.version} · 들어 있는 목록: ${cats.join(", ")} ${n}개`;
    $("bundleInfo").innerHTML =
      `확장에 들어 있는 목록 <b>${n}개</b>를 바로 읽었습니다. 따로 파일을 찾으실 필요 없습니다.`;
  } else {
    $("bundleInfo").innerHTML =
      `<span class="warn">확장에 들어 있는 목록을 읽지 못했습니다. 아래에서 파일을 고르세요.</span>`;
    jobsInfo();
  }
})();
setInterval(refresh, 2000);
